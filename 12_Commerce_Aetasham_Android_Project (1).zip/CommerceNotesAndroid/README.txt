# 12 Commerce Notes — Android project

Open this folder in Android Studio and build:
- Build > Build Bundle(s) / APK(s) > Build Bundle(s)
- For Play Store, create a signed Android App Bundle (.aab) via Build > Generate Signed Bundle / APK.

Package: com.example.commercenotes
Version: 1.0
